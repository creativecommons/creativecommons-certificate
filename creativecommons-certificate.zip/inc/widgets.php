<?php
/**
 * CERTIFICATE WIDGETS
 */

require STYLESHEETPATH . '/inc/widgets/cc-course-card.php';
require STYLESHEETPATH . '/inc/widgets/cc-event-card.php';
require STYLESHEETPATH . '/inc/widgets/cc-testimonial-card.php';
