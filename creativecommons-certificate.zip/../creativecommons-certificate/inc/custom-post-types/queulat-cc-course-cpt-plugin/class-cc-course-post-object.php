<?php

use Queulat\Post_Object;

class Cc_Course_Post_Object extends Post_Object {


}
