# Contributor Code of Conduct

The Creative Commons team is committed to fostering a welcoming community. This
project and all other Creative Commons open source projects are governed by our
[Code of Conduct][code_of_conduct]. Please report unacceptable behavior to
[conduct@creativecommons.org](mailto:conduct@creativecommons.org) per our
[reporting guidelines][reporting_guide].

For a history of updates, see the [page history here][updates].

[code_of_conduct]:https://opensource.creativecommons.org/community/code-of-conduct/
[reporting_guide]:https://opensource.creativecommons.org/community/code-of-conduct/enforcement/
[updates]:https://github.com/creativecommons/creativecommons.github.io-source/commits/master/content/community/code-of-conduct/contents.lr
